
from django.http import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404, redirect
from .models import Question
from .models import Option
from django.urls import reverse
from django.utils import timezone
from django.views import generic
from django.views.generic import ListView, DetailView

class IndexView(ListView):
    template_name = 'polls/index.html'
    context_object_name = 'latest_question_list'

    def get_queryset(self):
        return Question.objects.order_by('-pub_date')[:5]

class DetailView(DetailView):
    model = Question
    template_name = 'polls/detail.html'
    context_object_name = 'question'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['options'] = self.object.option_set.all()
        return context
   

class ResultsView(generic.DetailView):
    model = Question
    template_name = 'polls/results.html'

def vote(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    try:
        # Obtenemos la opción seleccionada por el usuario
        selected_option = question.option_set.get(pk=request.POST['option'])
    except (KeyError, Option.DoesNotExist):
        # Si no se seleccionó ninguna opción o la opción no existe
        return render(request, 'polls/detail.html', {
            'question': question,
            'error_message': "No seleccionaste una opción.",
        })
    else:
        # Si la opción existe, incrementamos los votos
        selected_option.votes += 1
        selected_option.save()

        request.session[f'vote_{question.id}'] = True

        # Redirigimos a la página de resultados
        return redirect('polls:resultados', pk=question.id)

def resultados(request, pk):
    question = get_object_or_404(Question, pk=pk)
    return render(request, 'polls/resultados.html', {'question': question})




